import{a as t}from"../chunks/entry.DjP7du0q.js";export{t as start};
